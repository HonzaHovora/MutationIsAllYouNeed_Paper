Benchmark: benchmarks\eval_lineage_v3_3b.json
Evaluated generations: 0, 20

Generation 0:
  Top axes: fact_guess_hypothesis_split=1.000, decision_vs_verification=0.750, operational_granularity=0.667
  Bottom axes: checkpoint_orientation=0.633, operational_granularity=0.667, reversibility_preference=0.667
Generation 20:
  Top axes: fact_guess_hypothesis_split=1.000, decision_vs_verification=0.750, checkpoint_orientation=0.700
  Bottom axes: operational_granularity=0.667, reversibility_preference=0.667, risk_vs_speed=0.667

Hygiene/corruption summary:
Generation 0: mean_hygiene=1.000, mean_corruption=0.000, top=none
Generation 20: mean_hygiene=1.000, mean_corruption=0.000, top=none

Largest axis shifts (first -> last generation):
  checkpoint_orientation: +0.067
  decision_vs_verification: +0.000
  fact_guess_hypothesis_split: +0.000
